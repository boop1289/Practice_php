<?php
declare(strict_types=1);
$name = basename(str_replace('\\', '/', (string)($_GET['file'] ?? '')));
$path = __DIR__ . '/uploads/' . $name;
if ($name === '' || $name === '.' || $name === '..' || !is_file($path)) {
    header('Location: index.php?error=' . urlencode('Файл не найден'));
    exit;
}
if (!unlink($path)) {
    header('Location: index.php?error=' . urlencode('Не удалось удалить файл'));
    exit;
}
file_put_contents(__DIR__ . '/log.txt', date('d.m.Y H:i:s') . ' | Удаление | ' . $name . PHP_EOL, FILE_APPEND | LOCK_EX);
header('Location: index.php?msg=' . urlencode('Файл удалён'));
exit;
