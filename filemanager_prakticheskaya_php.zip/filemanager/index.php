<?php
declare(strict_types=1);
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }
$maxFile = ini_get('upload_max_filesize');
$maxPost = ini_get('post_max_size');
$msg = $_GET['msg'] ?? '';
$error = $_GET['error'] ?? '';
function formatSize(int $bytes): string {
    $units = ['Б', 'КБ', 'МБ', 'ГБ'];
    $i = 0;
    $size = $bytes;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return round($size, 1) . ' ' . $units[$i];
}
$files = array_values(array_filter(scandir($uploadDir) ?: [], static function ($name) use ($uploadDir) {
    return $name !== '.' && $name !== '..' && is_file($uploadDir . $name) && $name !== '.gitkeep';
}));
$sort = $_GET['sort'] ?? 'name';
if (!in_array($sort, ['name', 'size', 'date'], true)) { $sort = 'name'; }
usort($files, static function ($a, $b) use ($sort, $uploadDir) {
    if ($sort === 'size') { return filesize($uploadDir . $b) <=> filesize($uploadDir . $a); }
    if ($sort === 'date') { return filemtime($uploadDir . $b) <=> filemtime($uploadDir . $a); }
    return strnatcasecmp($a, $b);
});
$totalBytes = array_sum(array_map(static fn($name) => filesize($uploadDir . $name), $files));
$logFile = __DIR__ . '/log.txt';
$logLines = is_file($logFile) ? (file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: []) : [];
$lastLogs = array_slice(array_reverse($logLines), 0, 10);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Файловый менеджер</title><link rel="stylesheet" href="style.css">
</head>
<body><div class="container">
<header><h1>Файловый менеджер</h1><p class="subtitle">Практическая работа: работа с файлами в PHP</p></header>
<?php if ($msg): ?><div class="alert success"><?= htmlspecialchars((string)$msg, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert error"><?= htmlspecialchars((string)$error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
<section class="card"><h2>Загрузка файлов</h2>
<div class="limits">Ограничения сервера: один файл — до <b><?= htmlspecialchars((string)$maxFile) ?></b>, весь запрос — до <b><?= htmlspecialchars((string)$maxPost) ?></b>.</div>
<form action="upload.php" method="post" enctype="multipart/form-data" class="upload-form">
<input type="file" name="userfile" required><button type="submit">Загрузить</button>
</form><p class="hint">Разрешены: jpg, jpeg, png, gif, pdf, txt, docx, xlsx, zip. Не более 5 МБ на файл.</p>
<form action="upload.php" method="post" enctype="multipart/form-data" class="upload-form extra-form">
<input type="file" name="files[]" multiple required><button type="submit">Загрузить несколько</button>
</form></section>
<section class="card"><h2>Загруженные файлы</h2><nav class="sorting">Сортировка: <a href="?sort=name">по имени</a> · <a href="?sort=size">по размеру</a> · <a href="?sort=date">по дате</a></nav>
<div class="table-wrap"><table><thead><tr><th>№</th><th>Имя файла</th><th>Размер</th><th>Дата загрузки</th><th>Действие</th></tr></thead><tbody>
<?php if (empty($files)): ?><tr><td colspan="5" class="empty">Файлов пока нет</td></tr>
<?php else: foreach ($files as $i => $name): ?>
<tr><td><?= $i + 1 ?></td><td>
<?php if (in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif'], true)): ?>
<img class="thumb" src="uploads/<?= rawurlencode($name) ?>" alt="Миниатюра">
<?php endif; ?>
<a href="uploads/<?= rawurlencode($name) ?>" download><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></a></td>
<td><?= formatSize((int)filesize($uploadDir . $name)) ?></td>
<td><?= date('d.m.Y H:i', (int)filemtime($uploadDir . $name)) ?></td>
<td><a class="btn-delete" href="delete.php?file=<?= urlencode($name) ?>" onclick="return confirm('Удалить этот файл?')">Удалить</a></td></tr>
<?php endforeach; endif; ?></tbody></table></div>
<p class="total">Всего файлов: <?= count($files) ?>, общий размер: <?= formatSize((int)$totalBytes) ?></p>
</section>
<section class="card"><h2>Последние действия</h2>
<?php if (!$lastLogs): ?><p class="hint">Записей пока нет</p><?php else: ?><ul class="history"><?php foreach ($lastLogs as $line): ?><li><?= htmlspecialchars($line, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?></ul><?php endif; ?>
</section><footer>Выполнил(а): ____________________ · Группа: ________ · <a href="info.php">Настройки PHP</a></footer>
</div></body></html>
