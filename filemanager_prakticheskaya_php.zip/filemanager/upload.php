<?php
declare(strict_types=1);
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
    header('Location: index.php?error=' . urlencode('Невозможно создать папку uploads'));
    exit;
}
function back(string $param, string $text): never {
    header('Location: index.php?' . $param . '=' . urlencode($text));
    exit;
}
function iniToBytes(string $val): int {
    $val = trim($val);
    $num = (int)$val;
    return match (strtoupper(substr($val, -1))) {
        'G' => $num * 1024 ** 3,
        'M' => $num * 1024 ** 2,
        'K' => $num * 1024,
        default => $num,
    };
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { back('error', 'Нужен POST-запрос'); }
if (empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > iniToBytes((string)ini_get('post_max_size'))) {
    back('error', 'Размер запроса превышает post_max_size (' . ini_get('post_max_size') . ')');
}
$items = [];
if (isset($_FILES['userfile'])) {
    $items[] = $_FILES['userfile'];
} elseif (isset($_FILES['files'])) {
    $group = $_FILES['files'];
    foreach ($group['name'] as $i => $name) {
        $items[] = [
            'name' => $name, 'tmp_name' => $group['tmp_name'][$i],
            'error' => $group['error'][$i], 'size' => $group['size'][$i],
        ];
    }
}
if (!$items) { back('error', 'Файл не выбран'); }
$allowed = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'txt', 'docx', 'xlsx', 'zip'];
$uploaded = 0;
foreach ($items as $file) {
    $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error !== UPLOAD_ERR_OK) {
        $message = match ($error) {
            UPLOAD_ERR_INI_SIZE => 'Файл превышает upload_max_filesize (' . ini_get('upload_max_filesize') . ')',
            UPLOAD_ERR_FORM_SIZE => 'Файл превышает ограничение формы',
            UPLOAD_ERR_PARTIAL => 'Файл загружен частично',
            UPLOAD_ERR_NO_FILE => 'Файл не выбран',
            UPLOAD_ERR_NO_TMP_DIR => 'Не найдена временная папка',
            UPLOAD_ERR_CANT_WRITE => 'Ошибка записи на диск',
            UPLOAD_ERR_EXTENSION => 'PHP остановил загрузку',
            default => 'Ошибка загрузки, код ' . $error,
        };
        back('error', $message);
    }
    if ((int)$file['size'] > 5 * 1024 * 1024) { back('error', 'Файл больше 5 МБ'); }
    $originalName = basename(str_replace('\\', '/', (string)$file['name']));
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) { back('error', 'Недопустимый тип файла: .' . $ext); }
    $name = preg_replace('/[^\p{L}\p{N}._-]/u', '_', $originalName);
    if (!$name || $name === '.' || $name === '..') { back('error', 'Недопустимое имя файла'); }
    $base = pathinfo($name, PATHINFO_FILENAME);
    $extension = pathinfo($name, PATHINFO_EXTENSION);
    $counter = 0;
    while (file_exists($uploadDir . $name)) {
        ++$counter;
        $name = time() . '_' . $counter . '_' . $base . '.' . $extension;
    }
    if (!move_uploaded_file((string)$file['tmp_name'], $uploadDir . $name)) {
        back('error', 'Не удалось сохранить файл');
    }
    file_put_contents(__DIR__ . '/log.txt', date('d.m.Y H:i:s') . ' | Загрузка | ' . $name . PHP_EOL, FILE_APPEND | LOCK_EX);
    ++$uploaded;
}
back('msg', 'Файлов загружено: ' . $uploaded);
